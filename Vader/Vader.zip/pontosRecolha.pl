%pontoRecolha-> idRua,tipo,quantidade
pontoRecolha(45,'Embalagens',90).
pontoRecolha(45,'Lixos',5940).
pontoRecolha(45,'Papel e Cartão',2370).
pontoRecolha(17,'Lixos',2480).
pontoRecolha(49,'Papel e Cartão',240).
pontoRecolha(49,'Lixos',2320).
pontoRecolha(15,'Papel e Cartão',240).
pontoRecolha(15,'Lixos',6320).
pontoRecolha(7,'Embalagens',140).
pontoRecolha(7,'Lixos',11240).
pontoRecolha(7,'Papel e Cartão',140).
pontoRecolha(51,'Lixos',240).
pontoRecolha(43,'Vidro',140).
pontoRecolha(43,'Lixos',12600).
pontoRecolha(43,'Organicos',90).
pontoRecolha(43,'Embalagens',90).
pontoRecolha(43,'Papel e Cartão',90).
pontoRecolha(56,'Lixos',140).
pontoRecolha(16,'Lixos',3150).
pontoRecolha(5,'Lixos',2530).
pontoRecolha(53,'Lixos',480).
pontoRecolha(53,'Vidro',240).
pontoRecolha(24,'Lixos',1440).
pontoRecolha(26,'Lixos',7960).
pontoRecolha(26,'Embalagens',480).
pontoRecolha(26,'Vidro',560).
pontoRecolha(26,'Organicos',720).
pontoRecolha(38,'Lixos',1920).
pontoRecolha(30,'Lixos',5720).
pontoRecolha(47,'Lixos',7590).
pontoRecolha(47,'Vidro',3180).
pontoRecolha(47,'Embalagens',6000).
pontoRecolha(47,'Papel e Cartão',6370).
pontoRecolha(21,'Papel e Cartão',480).
pontoRecolha(21,'Lixos',18290).
pontoRecolha(21,'Embalagens',330).
pontoRecolha(9,'Papel e Cartão',280).
pontoRecolha(9,'Lixos',1480).
pontoRecolha(48,'Lixos',1440).
pontoRecolha(48,'Embalagens',240).
pontoRecolha(36,'Papel e Cartão',1730).
pontoRecolha(36,'Lixos',1700).
pontoRecolha(40,'Papel e Cartão',760).
pontoRecolha(40,'Lixos',23460).
pontoRecolha(40,'Embalagens',280).
pontoRecolha(31,'Papel e Cartão',860).
pontoRecolha(31,'Lixos',10920).
pontoRecolha(35,'Lixos',5580).
pontoRecolha(35,'Papel e Cartão',280).
pontoRecolha(35,'Vidro',3000).
pontoRecolha(57,'Lixos',2700).
pontoRecolha(6,'Lixos',3240).
pontoRecolha(6,'Papel e Cartão',140).
pontoRecolha(4,'Lixos',180).
pontoRecolha(13,'Lixos',240).
pontoRecolha(3,'Lixos',230).
pontoRecolha(52,'Lixos',180).
pontoRecolha(11,'Papel e Cartão',1100).
pontoRecolha(11,'Lixos',480).
pontoRecolha(12,'Papel e Cartão',140).
pontoRecolha(12,'Lixos',1760).
pontoRecolha(10,'Lixos',3320).
pontoRecolha(10,'Papel e Cartão',760).
pontoRecolha(8,'Papel e Cartão',240).
pontoRecolha(8,'Lixos',3440).
pontoRecolha(2,'Lixos',140).
pontoRecolha(55,'Papel e Cartão',140).
pontoRecolha(55,'Lixos',1040).
pontoRecolha(1,'Lixos',610).
pontoRecolha(32,'Organicos',90).
pontoRecolha(32,'Papel e Cartão',570).
pontoRecolha(32,'Lixos',2100).
pontoRecolha(32,'Embalagens',570).
pontoRecolha(32,'Vidro',330).
pontoRecolha(28,'Papel e Cartão',480).
pontoRecolha(28,'Embalagens',480).
pontoRecolha(28,'Lixos',480).
pontoRecolha(28,'Vidro',240).
pontoRecolha(46,'Lixos',4320).
pontoRecolha(46,'Papel e Cartão',720).
pontoRecolha(46,'Embalagens',480).
pontoRecolha(46,'Vidro',240).
pontoRecolha(22,'Embalagens',140).
pontoRecolha(22,'Papel e Cartão',140).
pontoRecolha(22,'Vidro',380).
pontoRecolha(37,'Lixos',2400).
pontoRecolha(50,'Vidro',140).
pontoRecolha(50,'Papel e Cartão',380).
pontoRecolha(50,'Embalagens',380).
pontoRecolha(39,'Vidro',1070).
pontoRecolha(39,'Organicos',230).
pontoRecolha(25,'Vidro',140).
pontoRecolha(42,'Vidro',240).
pontoRecolha(41,'Vidro',140).
pontoRecolha(33,'Lixos',1440).
pontoRecolha(18,'Organicos',240).
pontoRecolha(18,'Vidro',240).
pontoRecolha(19,'Embalagens',480).
pontoRecolha(19,'Papel e Cartão',480).
pontoRecolha(19,'Lixos',480).
pontoRecolha(19,'Vidro',240).
pontoRecolha(44,'Embalagens',480).
pontoRecolha(44,'Lixos',240).
pontoRecolha(44,'Vidro',240).
pontoRecolha(20,'Organicos',480).
pontoRecolha(29,'Vidro',140).
pontoRecolha(29,'Lixos',840).
pontoRecolha(29,'Organicos',140).
pontoRecolha(27,'Organicos',140).
pontoRecolha(23,'Organicos',240).
pontoRecolha(23,'Vidro',240).
pontoRecolha(14,'Papel e Cartão',90).
pontoRecolha(14,'Lixos',280).
pontoRecolha(54,'Lixos',2400).
pontoRecolha(34,'Vidro',140).
pontoRecolha(34,'Organicos',140).
