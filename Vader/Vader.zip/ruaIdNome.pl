%ruaIdNome -> id, nome
rua(1,'Av 24 de Julho').
rua(2,'Bc Francisco André').
rua(3,'Bc da Boavista').
rua(4,'Bc da Moeda').
rua(5,'Bqr do Duro').
rua(6,'Cais do Sodré').
rua(7,'Lg Conde-Barão').
rua(8,'Lg Corpo Santo').
rua(9,'Pc Dom Luís I').
rua(10,'Pc Duque da Terceira').
rua(11,'Pc Ribeira Nova').
rua(12,'Pc São Paulo').
rua(13,'Pto Galega').
rua(14,'R António Maria Cardoso').
rua(15,'R Bernardino da Costa').
rua(16,'R Cais do Tojo').
rua(17,'R Corpo Santo').
rua(18,'R Correia Garção').
rua(19,'R Cruz dos Poiais de São Bento').
rua(20,'R Diário de Notícias').
rua(21,'R Dom Luís I').
rua(22,'R Emenda').
rua(23,'R Ferragial').
rua(24,'R Ferreiros a Santa Catarina').
rua(25,'R Imprensa Nacional').
rua(26,'R Instituto Industrial').
rua(27,'R Loreto').
rua(28,'R Marcos Portugal').
rua(29,'R Marechal Saldanha').
rua(30,'R Moeda').
rua(31,'R Nova do Carvalho').
rua(32,'R O Século').
rua(33,'R Poço dos Negros').
rua(34,'R Quintinha').
rua(35,'R Remolares').
rua(36,'R Ribeira Nova').
rua(37,'R Salgadeiras').
rua(38,'R Santa Catarina').
rua(39,'R São Bento').
rua(40,'R São Paulo').
rua(41,'R Teixeira').
rua(42,'R Vitor Cordon').
rua(43,'R da Boavista').
rua(44,'R da Cintura do Porto de Lisboa').
rua(45,'R do Alecrim').
rua(46,'Tv André Valente').
rua(47,'Tv Carvalho').
rua(48,'Tv Condessa do Rio').
rua(49,'Tv Corpo Santo').
rua(50,'Tv Guilherme Cossoul').
rua(51,'Tv Marquês de Sampaio').
rua(52,'Tv Ribeira Nova').
rua(53,'Tv Santa Catarina').
rua(54,'Tv Sequeiro').
rua(55,'Tv de São Paulo').
rua(56,'Tv do Cais do Tojo').
rua(57,'Tv dos Remolares').
